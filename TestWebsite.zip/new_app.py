from flask import Flask, request, redirect, url_for, render_template, session, jsonify
from flask_wtf import FlaskForm
from werkzeug.utils import secure_filename
import os
import csv
import pandas as pd
import matplotlib.pyplot as plt

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'mp3', 'wav'}
USER_CSV = 'users.csv'
DIARY_CSV = 'diary_entries.csv'
MENTAL_HEALTH_CSV = 'mental_health.csv'

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def read_csv(file_path):
    with open(file_path, mode='r', newline='') as file:
        reader = csv.DictReader(file)
        return list(reader)

def write_csv(file_path, fieldnames, data):
    with open(file_path, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

def append_csv(file_path, fieldnames, row):
    data = read_csv(file_path)
    data.append(row)
    write_csv(file_path, fieldnames, data)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', target="_self")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username_login = request.form['username']
        password_login = request.form['password']
        users = read_csv(USER_CSV)
        user = next((u for u in users if u['username'] == username_login and u['password'] == password_login), None)
        if user:
            session['user_id'] = user['id']
            return redirect(url_for('home', user_id=user['id']))
        else:
            return render_template('login.html', login_failed=True)
    return render_template('login.html', target="_self")

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('index'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username_user = request.form['username']
        name_user = request.form['name']
        email_user = request.form['email']
        password_user = request.form['password']
        confirmed_password_user = request.form['confirm-password']

        users = read_csv(USER_CSV)
        existing_user = next((u for u in users if u['username'] == username_user), None)
        if existing_user:
            return render_template('signup.html', user_found=True)

        if password_user != confirmed_password_user:
            return render_template('signup.html', password_mismatch=True)

        new_user = {
            'id': str(len(users) + 1),
            'name': name_user,
            'username': username_user,
            'email': email_user,
            'password': password_user
        }
        append_csv(USER_CSV, ['id', 'name', 'username', 'email', 'password'], new_user)
        return redirect(url_for('login'))

    return render_template('signup.html', password_mismatch=False, user_found=False, target="_self")

@app.route('/home/user/<int:user_id>', methods=['GET', 'POST'])
def home(user_id):
    users = read_csv(USER_CSV)
    user = next((u for u in users if u['id'] == str(user_id)), None)
    if not user:
        return redirect(url_for('index'))

    return render_template('home.html', user=user)

@app.route('/admin')
def admin():
    users = read_csv(USER_CSV)
    return render_template('admin.html', users=users)

@app.route('/fetch_diary_text', methods=['GET'])
def fetch_diary_text():
    if 'user_id' not in session:
        return jsonify({'error': 'User not logged in'}), 401

    user_id = session['user_id']
    df = pd.read_csv(MENTAL_HEALTH_CSV)
    user_data = df[df['User ID'] == int(user_id)]

    if user_data.empty:
        return jsonify({'error': 'No data found for user'}), 404

    # Get the latest entry for each category
    latest_entries = user_data.sort_values('Intensity', ascending=False).drop_duplicates('Category')
    latest_entries = latest_entries[['Extracted Concern', 'Category', 'Intensity']]

    # Get the latest entry
    latest_entry = latest_entries.iloc[0].to_dict()

    # Plotting the intensity graph
    plt.figure(figsize=(10, 6))
    for category in latest_entries['Category'].unique():
        category_data = user_data[user_data['Category'] == category]
        plt.plot(category_data['Intensity'], label=category)

    plt.xlabel('Entry Index')
    plt.ylabel('Intensity')
    plt.title('Intensity Graph for Each Category')
    plt.legend()
    graph_path = os.path.join(app.config['UPLOAD_FOLDER'], f'intensity_graph_user_{user_id}.png')
    plt.savefig(graph_path)
    plt.close()

    return jsonify({'latest_entry': latest_entry, 'graph_path': graph_path})


@app.route('/save_diary_entry', methods=['POST'])
def save_diary_entry():
    if 'user_id' not in session:
        return jsonify({'error': 'User not logged in'}), 401

    user_id = session['user_id']
    diary_text = request.json.get('diary_text')

    if not diary_text:
        return jsonify({'error': 'No diary text provided'}), 400

    new_entry = {
        'user_id': user_id,
        'entry': diary_text
    }
    append_csv(DIARY_CSV, ['user_id', 'entry'], new_entry)

    
    return jsonify({'success': 'Diary entry saved'})


if __name__ == '__main__':
    if not os.path.exists(USER_CSV):
        write_csv(USER_CSV, ['id', 'name', 'username', 'email', 'password'], [])
    if not os.path.exists(DIARY_CSV):
        write_csv(DIARY_CSV, ['user_id', 'entry'], [])
    app.run(debug=True)